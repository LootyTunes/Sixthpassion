import React, { useState, useEffect } from 'react';
import { Clock, Activity, Coffee, AlertCircle, Target, ListTodo, CheckCircle2, Circle } from 'lucide-react';

interface TimeStats {
  activeTime: number;
  idleTime: number;
  lastActivity: number;
}

interface ActionStep {
  text: string;
  completed: boolean;
}

interface TimeGoal {
  duration: number;
  timeUnit: 'minutes' | 'hours';
  isSet: boolean;
  description: string;
  actionPlan: ActionStep[];
}

function App() {
  const [timeStats, setTimeStats] = useState<TimeStats>({
    activeTime: 0,
    idleTime: 0,
    lastActivity: Date.now(),
  });
  const [isIdle, setIsIdle] = useState(false);
  const [timeGoal, setTimeGoal] = useState<TimeGoal>({
    duration: 30,
    timeUnit: 'minutes',
    isSet: false,
    description: '',
    actionPlan: [{ text: '', completed: false }],
  });
  const IDLE_THRESHOLD = 60000; // 1 minute in milliseconds

  useEffect(() => {
    let interval: number;
    
    const handleActivity = () => {
      const now = Date.now();
      
      setTimeStats(prev => {
        const timeSinceLastActivity = now - prev.lastActivity;
        
        if (isIdle) {
          return {
            ...prev,
            idleTime: prev.idleTime + timeSinceLastActivity,
            lastActivity: now,
          };
        }
        
        return {
          ...prev,
          activeTime: prev.activeTime + timeSinceLastActivity,
          lastActivity: now,
        };
      });
      
      setIsIdle(false);
    };

    const checkIdleStatus = () => {
      const now = Date.now();
      if (now - timeStats.lastActivity > IDLE_THRESHOLD) {
        setIsIdle(true);
      }
    };

    const events = ['mousemove', 'keydown', 'scroll', 'click'];
    events.forEach(event => document.addEventListener(event, handleActivity));

    interval = setInterval(checkIdleStatus, 1000);

    return () => {
      events.forEach(event => document.removeEventListener(event, handleActivity));
      clearInterval(interval);
    };
  }, [timeStats.lastActivity, isIdle]);

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  };

  const calculateEfficiency = () => {
    const totalTime = timeStats.activeTime + timeStats.idleTime;
    return totalTime === 0 ? 100 : Math.round((timeStats.activeTime / totalTime) * 100);
  };

  const getTargetMinutes = () => {
    return timeGoal.timeUnit === 'hours' ? timeGoal.duration * 60 : timeGoal.duration;
  };

  const calculateProgress = () => {
    if (!timeGoal.isSet) return 0;
    const totalMinutes = (timeStats.activeTime + timeStats.idleTime) / (1000 * 60);
    return Math.min(Math.round((totalMinutes / getTargetMinutes()) * 100), 100);
  };

  const calculateTaskProgress = () => {
    if (timeGoal.actionPlan.length === 0) return 0;
    const completedTasks = timeGoal.actionPlan.filter(step => step.completed).length;
    return Math.round((completedTasks / timeGoal.actionPlan.length) * 100);
  };

  const handleSetGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!timeGoal.description || timeGoal.actionPlan.some(action => !action.text.trim())) {
      alert('Please fill in all fields');
      return;
    }
    setTimeGoal(prev => ({ ...prev, isSet: true }));
  };

  const handleActionPlanChange = (index: number, value: string) => {
    setTimeGoal(prev => {
      const newActionPlan = [...prev.actionPlan];
      newActionPlan[index] = { ...newActionPlan[index], text: value };
      return { ...prev, actionPlan: newActionPlan };
    });
  };

  const toggleTaskCompletion = (index: number) => {
    setTimeGoal(prev => {
      const newActionPlan = [...prev.actionPlan];
      newActionPlan[index] = { 
        ...newActionPlan[index], 
        completed: !newActionPlan[index].completed 
      };
      return { ...prev, actionPlan: newActionPlan };
    });
  };

  const addActionStep = () => {
    setTimeGoal(prev => ({
      ...prev,
      actionPlan: [...prev.actionPlan, { text: '', completed: false }],
    }));
  };

  const removeActionStep = (index: number) => {
    setTimeGoal(prev => ({
      ...prev,
      actionPlan: prev.actionPlan.filter((_, i) => i !== index),
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 flex items-center gap-3">
            <Activity className="text-indigo-600" />
            Productivity Tracker
          </h1>

          {!timeGoal.isSet ? (
            <div className="bg-indigo-50 rounded-xl p-6 mb-8">
              <div className="flex items-center gap-3 mb-4">
                <Target className="text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">Set Your Session Goals</h2>
              </div>
              <form onSubmit={handleSetGoal} className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Session Duration
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={timeGoal.duration}
                      onChange={(e) => setTimeGoal(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                      className="w-full rounded-lg border-2 border-indigo-200 p-2 focus:outline-none focus:border-indigo-400"
                      placeholder="Enter duration"
                    />
                  </div>
                  <div className="w-1/3">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Time Unit
                    </label>
                    <select
                      value={timeGoal.timeUnit}
                      onChange={(e) => setTimeGoal(prev => ({ ...prev, timeUnit: e.target.value as 'minutes' | 'hours' }))}
                      className="w-full rounded-lg border-2 border-indigo-200 p-2 focus:outline-none focus:border-indigo-400"
                    >
                      <option value="minutes">Minutes</option>
                      <option value="hours">Hours</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Session Goal
                  </label>
                  <textarea
                    value={timeGoal.description}
                    onChange={(e) => setTimeGoal(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full rounded-lg border-2 border-indigo-200 p-2 focus:outline-none focus:border-indigo-400"
                    placeholder="What do you want to achieve in this session?"
                    rows={3}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Action Plan
                    </label>
                    <button
                      type="button"
                      onClick={addActionStep}
                      className="text-sm text-indigo-600 hover:text-indigo-800"
                    >
                      + Add Step
                    </button>
                  </div>
                  <div className="space-y-2">
                    {timeGoal.actionPlan.map((action, index) => (
                      <div key={index} className="flex gap-2">
                        <input
                          value={action.text}
                          onChange={(e) => handleActionPlanChange(index, e.target.value)}
                          className="flex-1 rounded-lg border-2 border-indigo-200 p-2 focus:outline-none focus:border-indigo-400"
                          placeholder={`Step ${index + 1}`}
                        />
                        {timeGoal.actionPlan.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeActionStep(index)}
                            className="text-red-500 hover:text-red-700 px-2"
                          >
                            ×
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Start Session
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-indigo-50 rounded-xl p-6 mb-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <Target className="text-indigo-600" />
                  <h2 className="text-xl font-semibold text-indigo-800">Session Progress</h2>
                </div>
                <button
                  onClick={() => setTimeGoal({ duration: 30, timeUnit: 'minutes', isSet: false, description: '', actionPlan: [{ text: '', completed: false }] })}
                  className="text-indigo-600 hover:text-indigo-800"
                >
                  Reset Session
                </button>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Goal:</h3>
                <p className="text-gray-700">{timeGoal.description}</p>
              </div>

              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-800">Action Plan:</h3>
                  <span className="text-sm text-gray-600">
                    {calculateTaskProgress()}% Complete
                  </span>
                </div>
                <ul className="space-y-2">
                  {timeGoal.actionPlan.map((action, index) => (
                    <li 
                      key={index} 
                      className="flex items-center gap-2 text-gray-700 p-2 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                      onClick={() => toggleTaskCompletion(index)}
                    >
                      {action.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      ) : (
                        <Circle className="w-5 h-5 text-gray-400" />
                      )}
                      <span className={action.completed ? 'line-through text-gray-500' : ''}>
                        {action.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-2">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Time Progress ({calculateProgress()}%)</span>
                  <span>{timeGoal.duration} {timeGoal.timeUnit} goal</span>
                </div>
                <div className="relative h-4 bg-indigo-100 rounded-full overflow-hidden">
                  <div
                    className="absolute h-full bg-indigo-600 transition-all duration-500"
                    style={{ width: `${calculateProgress()}%` }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-green-50 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="text-green-600" />
                <h2 className="text-xl font-semibold text-green-800">Active Time</h2>
              </div>
              <p className="text-2xl font-bold text-green-700">{formatTime(timeStats.activeTime)}</p>
            </div>

            <div className="bg-orange-50 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <Coffee className="text-orange-600" />
                <h2 className="text-xl font-semibold text-orange-800">Idle Time</h2>
              </div>
              <p className="text-2xl font-bold text-orange-700">{formatTime(timeStats.idleTime)}</p>
            </div>
          </div>

          <div className="bg-indigo-50 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="text-indigo-600" />
              <h2 className="text-xl font-semibold text-indigo-800">Current Status</h2>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-lg">
                <span className={`inline-block w-3 h-3 rounded-full mr-2 ${isIdle ? 'bg-orange-500' : 'bg-green-500'}`}></span>
                {isIdle ? 'Idle' : 'Active'}
              </p>
              <p className="text-2xl font-bold text-indigo-700">
                {calculateEfficiency()}% Efficient
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;